"""Services."""
from pyicloud.services.calendar import CalendarService
from pyicloud.services.findmyiphone import FindMyiPhoneServiceManager
from pyicloud.services.ubiquity import UbiquityService
from pyicloud.services.contacts import ContactsService
from pyicloud.services.reminders import RemindersService
from pyicloud.services.photos import PhotosService
from pyicloud.services.account import AccountService
from pyicloud.services.drive import DriveService
