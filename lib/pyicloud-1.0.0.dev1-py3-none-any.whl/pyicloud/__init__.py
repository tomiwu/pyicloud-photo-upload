"""The pyiCloud library."""
import logging
from pyicloud.base import PyiCloudService

__version__ = "1.0.0.dev1"

logging.getLogger(__name__).addHandler(logging.NullHandler())
